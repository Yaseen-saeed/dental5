// اللوجيك سليم مفيهوش حاجة
const slides = document.querySelector(".slides");
const next = document.getElementById("next");
const prev = document.getElementById("prev");
const totalSlides = 10; // عدد الصور
let currentIndex = 0;

// عند النقر على السهم الأيمن
next.addEventListener("click", () => {
  currentIndex = (currentIndex + 1) % totalSlides; // الانتقال إلى الصورة التالية (دائري)
  updateSlider();
});

// عند النقر على السهم الأيسر
prev.addEventListener("click", () => {
  currentIndex = (currentIndex - 1 + totalSlides) % totalSlides; // الانتقال إلى الصورة السابقة (دائري)
  updateSlider();
});

// تحديث موقع الشرائح
function updateSlider() {
  console.log(currentIndex);
  slides.style.transform = `translateX(-${currentIndex * 100}%)`; // تحريك الشرائح
}
